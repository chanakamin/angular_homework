export class Time {
    public hour: number;
    public minutes: number;

    /**
     *
     */
    constructor(_hour: number, _minutes: number) {
        this.hour = _hour;
        this.minutes = _minutes;
    }
}
